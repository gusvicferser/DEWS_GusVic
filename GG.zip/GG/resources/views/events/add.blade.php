@extends('layout')

@section('title', 'Index')

@section('welcome')
<div class="container-fluid d-flex m-auto align-items-center justify-content-center w-50">
    <img class="w-75 h-75" src="img/GG_Icon.png" alt="GG_Logo">
</div>
@endsection
