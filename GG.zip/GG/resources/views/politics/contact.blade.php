@extends('layout')

@section('title', 'Index')

@section('content')
<div class="container-fluid d-flex m-auto align-items-center justify-content-center">
    <img src="img/GG_Icon.png" alt="GG_Logo">
</div>
@endsection
