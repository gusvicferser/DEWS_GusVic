<?php $__env->startSection('title', 'Index'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <img src="img/GG_Icon.png" alt="GG_Logo">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GG\resources\views/politics/contact.blade.php ENDPATH**/ ?>