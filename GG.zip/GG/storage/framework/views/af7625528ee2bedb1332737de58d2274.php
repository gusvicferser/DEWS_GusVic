<?php $__env->startSection('title', 'Index'); ?>

<?php $__env->startSection('welcome'); ?>
    <div class="container-fluid">
        <div class="container-fluid d-flex m-auto align-items-center justify-content-center p-3">
            <h1>¡Me temo que eso que buscas no existe!</h1>
        </div>
        <div class="container-fluid d-flex m-auto align-items-center justify-content-center w-50">
            <img class="w-75 h-75" src="img/GG_Icon.png" alt="GG_Logo">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\GG\resources\views/errors/404.blade.php ENDPATH**/ ?>