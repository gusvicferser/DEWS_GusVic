<?php
    /**
     * Página reservada para el footer de los juegos de cartas.
     * @author: Gustavo Víctor
     * @version: 1.0
     */
?>

<footer class="pieDePagina">
    <div class="box">
        <h1>Gustavo Víctor</h1>

    </div>
    <img src="/images/gus.jpg" alt="Yo mismo, Gustavo"></img>
</div>
    <div class="derechos">
        <span class="negrita">Gustavo Victor Fernandez Serantes</span>

        
    </div>
</footer>

     